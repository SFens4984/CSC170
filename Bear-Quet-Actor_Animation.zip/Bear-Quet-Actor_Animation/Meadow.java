import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class MyWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Meadow extends World
{

    /**
     * Constructor for objects of class MyWorld.
     * 
     */
    public Meadow()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(800, 600, 1); 
        prepare();
    }
    
    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    Heart heart1;
    Heart heart2;
    Heart heart3;
    private void prepare()
    {
        heart1 = new Heart();
        addObject(heart1,30,30);
        heart2 = new Heart();
        addObject(heart2,85,30);
        heart3 = new Heart();
        addObject(heart3,140,30);
        Flower flower1 = new Flower();
        addObject(flower1,400,110);
        Flower flower2 = new Flower();
        addObject(flower2,100,300);
        Flower flower3 = new Flower();
        addObject(flower3,400,300);
        Flower flower4 = new Flower();
        addObject(flower4,400,490);
        Flower flower5 = new Flower();
        addObject(flower5,700,300);
        Bee bee1 = new Bee();
        addObject(bee1,90,100);
        bee1.turnTowards(400,300);
        bee1.setSpawn();
        Bee bee2 = new Bee();
        addObject(bee2,710,100);
        bee2.turnTowards(400,300);
        bee2.setSpawn();
        Bee bee3 = new Bee();
        addObject(bee3,90,500);
        bee3.turnTowards(400,300);
        bee3.setSpawn();
        Bee bee4 = new Bee();
        addObject(bee4,710,500);
        bee4.setSpawn();
        bee4.turnTowards(400,300);
        Bear bear = new Bear();
        addObject(bear,400,571);
        updateScore(5,3);
    }
    
    public void updateScore(int flowers, int health){
        showText(("Flowers collected: " + flowers), 680, 30);
        if(health < 3)
            heart3.harmed();
        if(health < 2)
            heart2.harmed();
        if(health < 1)
            heart1.harmed();
        /* if(flowers == 5 || health == 0)
         *  gameState = 0;
         * */
    }
    public void act(){
        updateScore(Bear.getFlowers(), Bear.getHealth());
    }
}
