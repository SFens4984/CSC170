import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Bee here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Bee extends Actor
{
    private int delay;
    private final int RESPAWN_TIMER = 300;
    private int[] startPosition = new int[2];
    private boolean respawn;
    public Bee(){
        GreenfootImage image = getImage();  
        image.scale(35, 35);
        setImage(image);
        delay = 0;
        respawn = false;
    }
    /**
     * Act - do whatever the Bee wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        // Add your action code here.
        if(respawn){
            respawn = false;
            GreenfootImage image = getImage();
            image.setTransparency(255);
            this.setLocation(this.startPosition[0], this.startPosition[1]);
            this.turnTowards(400,300);
        }
        move(1);
        chooseDirection();
        if(this.isTouching(Bear.class)){
            this.sting();
        }
    }
    public void setSpawn(){
        this.startPosition[0] = this.getX();
        this.startPosition[1] = this.getY();
    }
    private void chooseDirection(){
        if(this.isAtEdge()){
            turn(180);
        }else if (delay == 6){
            int turnChance = (int)(Math.random() * 20);
            if(turnChance == 1)
                turn(1 + (int)(Math.random() * 45));
            else if(turnChance == 20)
                turn(-1 * (1 + (int)(Math.random() * 45)));
            delay = 0;
        }else
            delay++;
    }
    public void sting(){
        Bear.getStung();
        this.setLocation(0,0);
        GreenfootImage image = getImage();
        image.setTransparency(0);
        this.respawn = true;
        this.sleepFor(RESPAWN_TIMER);
    }
}
