import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Bear here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Bear extends Actor
{
    private int flowersCollected;
    private int health;
    public Bear(){
        GreenfootImage image = getImage();  
        image.scale(75, 60);
        setImage(image);
        flowersCollected = 0;
        health = 3;
    }
    /**
     * Act - do whatever the Bear wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        // Add your action code here.
        userMove();
    }
    
    public void userMove(){
        if(Greenfoot.isKeyDown("w")){
            turn(-90);
            move(1);
        }else if(Greenfoot.isKeyDown("a")){
            turn(180);
            move(1);
        }else if(Greenfoot.isKeyDown("s")){
            turn(90);
            move(1);
        }else if(Greenfoot.isKeyDown("d")){
            move(1);
        }
        setRotation(0);
    }
}
