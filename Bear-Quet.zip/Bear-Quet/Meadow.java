import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class Meadow extends World
{

    /**
     * Constructor for objects of class MyWorld.
     * 
     */
    private static int gameState = 0; //0 for paused, 1 for running
    private static char winLose = 'n'; //'n' for no win/lose, 'w' for win, 'l' for lose
    public Meadow()
    {    
        super(800, 600, 1); 
        prepare();
    }
    
    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    
    /*
     * It improves performance to initialize the major actors directly within
     * the Meadow class, especially during subsequent replays of the game,
     * rather than creating new versions every run.
     */
    Heart heart1 = new Heart();
    Heart heart2 = new Heart();
    Heart heart3 = new Heart();
    Flower flower1 = new Flower();
    Flower flower2 = new Flower();
    Flower flower3 = new Flower();
    Flower flower4 = new Flower();
    Flower flower5 = new Flower();
    Bee bee1 = new Bee();
    Bee bee2 = new Bee();
    Bee bee3 = new Bee();
    Bee bee4 = new Bee();
    Bear bear = new Bear();
    
    StartScreen lose1 = new StartScreen("You lose...", "result");
    StartScreen lose2 = new StartScreen("The bear ran away from the stinging bees", "instruction");
    StartScreen win1 = new StartScreen("You Win!", "result");
    StartScreen win2 = new StartScreen("The bear made a lovely bouquet!", "instruction");
    StartScreen restart = new StartScreen("Press SPACE to play again", "start");
    StartScreen title = new StartScreen("Bear-Quet", "title");
    StartScreen instruct1 = new StartScreen("Use WASD to move", "instruction");
    StartScreen instruct2 = new StartScreen("Gather 5 flowers to win", "instruction");
    StartScreen instruct3 = new StartScreen("Avoid the bees", "instruction");
    StartScreen instruct4 = new StartScreen("3 stings and you lose", "instruction");
    StartScreen start = new StartScreen("Press SPACE to start", "start");
    
    private void prepare()
    {
        addObject(flower1,400,110);
        addObject(flower2,100,300);
        addObject(flower3,400,300);
        addObject(flower4,400,490);
        addObject(flower5,700,300);

        Tree tree1 = new Tree();
        addObject(tree1,509,356);
        Tree tree2 = new Tree();
        addObject(tree2,670,231);
        Tree tree3 = new Tree();
        addObject(tree3,263,153);
        Tree tree4 = new Tree();
        addObject(tree4,240,472);
        Tree tree5 = new Tree();
        addObject(tree5,200,391);

        plantTrees(0, 800, 25, true);
        plantTrees(40, 760, 35, true);
        plantTrees(60, 520, 0, false);
        plantTrees(60, 520, 750, false);
        plantTrees(0, 320, 560, true);
        plantTrees(480, 800, 560, true);
        plantTrees(40, 280, 570, true);
        plantTrees(520, 760, 570, true);

        addObject(bee1,90,100);
        bee1.turnTowards(400,300);
        bee1.setSpawn();
        addObject(bee2,710,100);
        bee2.turnTowards(400,300);
        bee2.setSpawn();
        addObject(bee3,90,500);
        bee3.turnTowards(400,300);
        bee3.setSpawn();
        addObject(bee4,710,500);
        bee4.setSpawn();
        bee4.turnTowards(400,300);
        
        addObject(bear,400,571);

        addObject(heart1,30,30);
        addObject(heart2,85,30);
        addObject(heart3,140,30);
        
        addObject(title, 400, 180);
        addObject(instruct1, 400, 255);
        addObject(instruct2, 400, 285);
        addObject(instruct3, 400, 315);
        addObject(instruct4, 400, 345);
        addObject(start, 400, 400);
        addObject(win1, 400, 260);
        win1.hide();
        addObject(win2, 400, 320);
        win2.hide();
        addObject(lose1, 400, 260);
        lose1.hide();
        addObject(lose2, 400, 320);
        lose2.hide();
        addObject(restart, 400, 400);
        restart.hide();
        
        updateScore(0,3);
    }
    
    public void updateScore(int flowers, int health){
        showText(("Flowers collected: " + flowers), 680, 30);
        if(health < 3)
            heart3.harmed();
        if(health < 2)
            heart2.harmed();
        if(health < 1)
            heart1.harmed();
        if(flowers == 5 || health == 0){
            if(flowers == 5)
                winLose = 'w';
            else if(health == 0)
                winLose = 'l';
            gameState = 0;
        }
    }
    
    /*
     * I made this method purely so I didn't have to manually place
     * about 70 trees.
     */
    public void plantTrees(int start, int stop, int line, boolean horizontal){
        if(horizontal){
            for(int i = start; i <= stop; i+=80){
                Tree tree = new Tree();
                addObject(tree, i, line);
            }
        }else{
            if(line < (this.getWidth() / 2)){
                for(int i = start; i <= stop; i+=80){
                    Tree tree1 = new Tree();
                    addObject(tree1, line, i);
                    Tree tree2 = new Tree();
                    addObject(tree2, (line+40), (i+40));
                }
            }else{
                for(int i = start; i <= stop; i+=80){
                    Tree tree1 = new Tree();
                    addObject(tree1, (line+40), i);
                    Tree tree2 = new Tree();
                    addObject(tree2, line, (i+40));
                }
            }
        }
    }
    
    public void act(){
        /*
         * Updates score while the game is running,
         * Shows appropriate StartScreens when game is stopped
         */
        if(gameState == 1)
            updateScore(bear.getFlowers(), bear.getHealth());
        else{
            setPaintOrder(StartScreen.class);
            switch(winLose){
                case 'n': 
                    title.show();
                    instruct1.show();
                    instruct2.show();
                    instruct3.show();
                    instruct4.show();
                    start.show();
                    break;
                case 'l': 
                    lose1.show();
                    lose2.show();
                    restart.show();
                    break;
                case 'w': 
                    win1.show();
                    win2.show();
                    restart.show();
                    break;
            }
            if(Greenfoot.isKeyDown("space")){
                if(!(winLose == 'n')){
                    winLose = 'n';
                    bear.reset();
                    bee1.reset();
                    bee2.reset();
                    bee3.reset();
                    bee4.reset();
                    
                    addObject(flower1,400,110);
                    addObject(flower2,100,300);
                    addObject(flower3,400,300);
                    addObject(flower4,400,490);
                    addObject(flower5,700,300);
                    
                    heart1.heal();
                    heart2.heal();
                    heart3.heal();
                }
                gameState = 1;
            }
        }
    }
    public static int getGameState(){
        return gameState;
    }
}
