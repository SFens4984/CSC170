import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class Bee extends Actor
{
    private int delay;
    private final int RESPAWN_TIMER = 300;
    private int[] startPosition = new int[2];
    private boolean respawn;
    public Bee(){
        GreenfootImage image = getImage();  
        image.scale(35, 35);
        setImage(image);
        delay = 0;
        respawn = false;
    }
    
    public void act()
    {
        if(Meadow.getGameState() == 1){
            if(respawn){
                respawn = false;
                GreenfootImage image = getImage();
                image.setTransparency(255);
                this.setLocation(this.startPosition[0], this.startPosition[1]);
                this.turnTowards(400,300);
            }
            move(2);
            chooseDirection();
            if(this.isTouching(Bear.class)){
                this.sting();
            }
        }
    }
    public void setSpawn(){
        this.startPosition[0] = this.getX();
        this.startPosition[1] = this.getY();
    }
    
    /*
     * Turn around(180 degrees) if at an edge
     * Roll a 1/10 chance to turn between from 1-45 degrees right or left
     * every .1 seconds
     */
    private void chooseDirection(){
        if(this.isAtEdge()){
            turn(180);
        }else if (delay == 6){
            int turnChance = (int)(Math.random() * 20);
            if(turnChance == 1)
                turn(1 + (int)(Math.random() * 45));
            else if(turnChance == 20)
                turn(-1 * (1 + (int)(Math.random() * 45)));
            delay = 0;
        }else
            delay++;
    }
    /*
     * When a bee stings, make it invisible, move it where it can't sting again,
     * and have it wait to respawn
     */
    public void sting(){
        Bear.getStung();
        this.setLocation(0,0);
        GreenfootImage image = getImage();
        image.setTransparency(0);
        this.respawn = true;
        this.sleepFor(RESPAWN_TIMER);
    }
    /*
     * Returns bees to their starting location & orientation
     * and takes them out of respawning
     */
    public void reset(){
        GreenfootImage image = getImage();
        image.setTransparency(255);
        this.setLocation(this.startPosition[0], this.startPosition[1]);
        this.turnTowards(400,300);
        delay = 0;
        this.sleepFor(1);
    }
}
