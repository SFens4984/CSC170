import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class Flower extends Actor
{
    public Flower(){
        GreenfootImage image = getImage();  
        image.scale(50, 50);
        setImage(image);
    }
}
