import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class InstructText extends Actor
{
    private int size = 30;
    private Color background = Color.WHITE;
    public InstructText(String text, String type){
        if(type.equals("title")){
            size = 100;
            background = Color.YELLOW;
        }else if (type.equals("start")){
            size = 60;
            background = Color.GREEN;
        }else if(type.equals("result")){
            size = 70;
        }
        setImage(new GreenfootImage(text, size, Color.BLACK, background));
    }
    public void act()
    {
        if(Meadow.getGameState() == 1){
            hide();
        }
    }
    public void show(){
        GreenfootImage image = getImage();
        image.setTransparency(255);
    }
    public void hide(){
        GreenfootImage image = getImage();
        image.setTransparency(0);
    }
}
