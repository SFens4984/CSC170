import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class ScoreKeeper extends Actor
{
    private int time;
    private static int countdown = 60;
    public ScoreKeeper(){
        time = 0;
        setImage(new GreenfootImage("Time: " + time + " seconds\n" + "Flowers collected: " + Bear.getFlowers(), 24, Color.BLACK, Color.WHITE));
    }
    public void act()
    {
        if(Meadow.getGameState() == 1){
            if(countdown == 0){
                time++;
                countdown = 60;
            }else{
                countdown--;
            }
        }
        setImage(new GreenfootImage("Time: " + time + " seconds\n" + "Flowers collected: " + Bear.getFlowers(), 24, Color.BLACK, Color.WHITE));
    }
    public void reset(){
        time = 0;
        countdown = 60;
        setImage(new GreenfootImage("Time: " + time + " seconds\n" + "Flowers collected: " + Bear.getFlowers(), 24, Color.BLACK, Color.WHITE));
    }
}
