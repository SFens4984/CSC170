import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class Heart extends Actor
{
    public void harmed()
    {
        GreenfootImage image = getImage();
        image.setTransparency(0);
    }
    public void heal()
    {
        GreenfootImage image = getImage();
        image.setTransparency(255);
    }
}
