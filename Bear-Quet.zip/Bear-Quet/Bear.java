import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class Bear extends Actor
{
    private static int flowersCollected;
    private static int health;
    public Bear(){
        GreenfootImage image = getImage();  
        image.scale(65, 50);
        setImage(image);
        flowersCollected = 0;
        health = 3;
    }
    public static int getHealth(){
        return health;
    }
    public static int getFlowers(){
        return flowersCollected;
    }
    public void act()
    {
        if(Meadow.getGameState() == 1){
            userMove();
            if(nearFlower()){
                pickFlower();
            }
        }
    }
    
    public void userMove(){
        Actor collidingTree = getOneIntersectingObject(Tree.class);
        boolean moving = false;
        /*
         * If there's a tree intersecting the bear, move it directly away
         * from the tree.
         * Only allow movement if there aren't any intersecting trees.
         */
        if (collidingTree != null) {
            turnTowards(collidingTree.getX(), collidingTree.getY());
            turn(180);
            move(1);
        }else{
            if(Greenfoot.isKeyDown("w")){
                turn(-90);
                moving = true;
            }else if(Greenfoot.isKeyDown("a")){
                turn(180);
                moving = true;
            }else if(Greenfoot.isKeyDown("s")){
                turn(90);
                moving = true;
            }else if(Greenfoot.isKeyDown("d")){
                moving = true;
            }
        }
        
        if(moving){
            move(2);
        }
        setRotation(0);
    }
    public boolean nearFlower(){
        return this.isTouching(Flower.class);
    }
    public void pickFlower(){
        this.removeTouching(Flower.class);
        Greenfoot.playSound("collect.mp3");
        flowersCollected++;
    }
    public static void getStung(){
        Greenfoot.playSound("oof.mp3");
        health--;
    }
    public void reset(){
        health = 3;
        flowersCollected = 0;
        this.setLocation(400,571);
    }
}
