import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class Tree extends Actor
{
    public Tree(){
        GreenfootImage image = getImage();  
        image.scale(80, 100);
        setImage(image);
    }
}
